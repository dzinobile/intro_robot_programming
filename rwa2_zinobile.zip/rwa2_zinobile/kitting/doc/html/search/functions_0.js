var searchData=
[
  ['check_5finputs_13',['check_inputs',['../kitting_8cpp.html#ad712f8d275f6b19379cb35969f806dad',1,'check_inputs(int ri, int gi, int bi, int rg, int gg, int bg):&#160;kitting.cpp'],['../kitting_8hpp.html#ad712f8d275f6b19379cb35969f806dad',1,'check_inputs(int ri, int gi, int bi, int rg, int gg, int bg):&#160;kitting.cpp']]]
];
