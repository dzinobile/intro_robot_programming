var searchData=
[
  ['pick_18',['pick',['../kitting_8cpp.html#a1da3b45d5a190dd191b51c99b09ac72b',1,'pick(int int_color, int bin_status, bool gripper_empty):&#160;kitting.cpp'],['../kitting_8hpp.html#a3260b6dcc490a9144c34c6af05c8b535',1,'pick(int color, int bin_status, bool gripper_empty):&#160;kitting.cpp']]],
  ['place_19',['place',['../kitting_8cpp.html#a501472bb4e47fb34ea4ca18650628474',1,'place(int int_color, int blocks_needed, bool gripper_empty):&#160;kitting.cpp'],['../kitting_8hpp.html#ae218e25b0f31c2d79e9838f1b3076a72',1,'place(int color, int blocks_needed, bool gripper_empty):&#160;kitting.cpp']]]
];
